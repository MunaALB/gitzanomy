<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class My_PHPMailer {

    public function __construct() {
        require_once('PHPMailer/class.phpmailer.php');
    }

    /* public function My_PHPMailer() {

      } */
}

?>