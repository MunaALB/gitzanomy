<style>
    .errorPrint{
        font-size: 12px;
        color: #af2000 !important;
        padding: 5px 5px;
        display: none;
    }
    .fa_btn {
        background: #f74f00;
        color: #ffffff !important;
        padding: 4px 6px !important;
        margin-top: 0px;
        border-radius: 30px;
        margin-left: 0px;
    }
</style>
<div class="content-wrapper">
    <div class="content-header sty-one">
        <h1><?php if (isset($edit)) {
    echo 'Edit Sub Admin';
} else {
    echo 'Sub Admin Management';
} ?></h1>
        <ol class="breadcrumb">
            <li><a href="<?= base_url('admin'); ?>">Home</a></li>
            <li><i class="fa fa-angle-right"></i> Sub Admin Management</li>
        </ol>
    </div>

    <div class="content">
<?= $this->session->flashdata('response'); ?>
        <div class="row">
<?php if (!isset($edit)) { ?>
                <div class="col-md-5">
                    <div class="card">
                        <form method="POST" id="regForm" enctype="multipart/form-data">
                            <div class="card-body"> 
                                <div class="row">
                                    <div class="col-md-12">
                                        <label>Email</label>
                                        <input type="email" id="email" class="form-control mb-4 regInputs" name="email" placeholder="Email" data-title="Email">
                                        <p class="errorPrint" id="emailError"></p>
    <?= form_error('email') ?>
                                    </div>
                                    <div class="col-md-12">
                                        <label>Username</label>
                                        <input type="text" id="username" class="form-control mb-4 regInputs" name="username" placeholder="Username"  data-title="Username">
                                        <p class="errorPrint" id="usernameError"></p>
    <?= form_error('username') ?>
                                    </div>
                                    <div class="col-md-12">
                                        <button type="button" id="add_product_set" class="composemail mt-4 pull-right" onclick="saveData(this)">Submit</button>  
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
<?php } else { ?>
                <div class="col-md-5">
                    <div class="card">
                        <form method="POST" id="regForm" enctype="multipart/form-data">
                            <div class="card-body"> 
                                <div class="row">
                                    <div class="col-md-12">
                                        <label>Email</label>
                                        <input type="email" id="email" class="form-control mb-4 regInputs" value="<?= $edit['email'] ?>" onchange="setName(this);" placeholder="Email" data-title="Email">
                                        <p class="errorPrint" id="emailError"></p>
    <?= form_error('email') ?>
                                    </div>
                                    <div class="col-md-12">
                                        <label>Username</label>
                                        <input type="text" id="username" class="form-control mb-4 regInputs" value="<?= $edit['username'] ?>" name="username" placeholder="Username"  data-title="Username">
                                        <p class="errorPrint" id="usernameError"></p>
    <?= form_error('username') ?>
                                    </div>
                                    <div class="col-md-12">
                                        <button type="button" id="add_product_set" class="composemail mt-4 pull-right" onclick="saveData(this)">Submit</button>  
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
<?php } ?>

            <div class="col-md-7">
                <div class="card"> 
                    <div class="card-body">

                        <div class="table-responsive table-image">
                            <table id="example1" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Sr.no</th>
                                        <th>Username </th>
                                        <th>Email </th>
                                        <th>Status</th> 
                                        <th>Action </th> 
                                    </tr>
                                </thead>
                                <tbody>
<?php $count = 1;
foreach ($admin_list as $listing) { ?>
                                        <tr>
                                            <td><?= $count ?></td>
                                            <td><?= $listing['username'] ?></td>
                                            <td><?= $listing['email'] ?></td>
                                            <td>
                                                <div class="mytoggle">
                                                    <label class="switch">
                                                        <input type="checkbox" <?php
                                                    if ($listing['status'] == '1'): echo "checked";
                                                    endif;
                                                    ?> onchange="checkStatus(this, '<?= $listing['id']; ?>');">
                                                        <span class="slider round"></span>
                                                    </label>
                                                </div>
                                            </td> 
                                            <td>
                                                <a class="composemail fa_btn" href="<?php echo site_url('admin/sub-admin-list/' . $listing['id']); ?>"><i class="fa fa-edit"></i></a>
                                                <!--<a class="composemail fa_btn" onclick="deleleData(this, '<?= $listing['status_id']; ?>');"><i class="fa fa-trash-o"></i></a>-->
                                            </td> 
                                        </tr> 
    <?php $count++;
} ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        function showErrorMessage(id, msg) {
            $("#" + id).empty();
            $("#" + id).append(msg);
            $("#" + id).css('display', 'block');
        }

        function checkStatus(obj, id) {
            var txt;
            var checked = $(obj).is(':checked');
            if (checked == true) {
                var status = 1;
            } else {
                var status = 0;
            }

            if (id) {
                $.ajax({
                    url: "<?= base_url(); ?>admin/Admin/ajax_method",
                    type: 'post',
                    data: 'method=updateStatus&id=' + id + '&action=' + status + '&type=7',
                    success: function (data) {
                        var dt = $.trim(data);
                        //alert(dt);
                        var jsonData = $.parseJSON(dt);
                        if (jsonData['error_code'] == "100") {
                            location.reload();
                        } else {
                            alert(jsonData['message']);
                        }
                    }
                });
            } else {
                alert("Something Wrong");
                location.reload();
            }
        }
    </script>
    <script type="text/javascript">
        function saveData(o) {
            $(".errorPrint").css('display', 'none');
            var idValidate = false;
            $(".regInputs").each(function (index, value) {
                // console.log('div' + index + ':' + $(this).attr('id'));
                if ($(this).val()) {
                    $("#" + $(this).attr('id') + 'Error').css('display', 'none');
                } else {
                    idValidate = true;
                    $("#" + $(this).attr('id') + 'Error').empty();
                    $("#" + $(this).attr('id') + 'Error').append('*' + $(this).attr('data-title') + ' is required field');
                    $("#" + $(this).attr('id') + 'Error').css('display', 'block');
                    //$("html, body").animate({ scrollTop: 0 }, "slow");
                }
            });
            if (idValidate) {
                return false;
            } else {
                $("#regForm").submit();
            }
        }


        function setName(obj) {
            $(obj).attr('name','email');
        }
    </script>  