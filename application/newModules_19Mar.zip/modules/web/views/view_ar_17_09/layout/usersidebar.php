                    <div class="module category-style userside-menu">
                        <div class="user-profileimage">
                            <div class="avatar-upload">
                                <div class="avatar-edit">
                                    <input type='file' id="imageUpload" accept=".png, .jpg, .jpeg" />
                                    <label for="imageUpload"></label>
                                </div>
                                <div class="avatar-preview">
                                    <div id="imagePreview" style="background-image: url('<?php echo base_url(); ?>assets/web/images/user/userimage.jpg');">
                                    </div>
                                </div>
                            </div>
                            <h3>Mo Danish</h3>
                        </div>
                        <div class="modcontent">
                            <div class="box-category">
                                <ul id="cat_accordion" class="list-group">
                                    <li class="active"><a href="<?php echo base_url('my-account'); ?>" class="cutom-parent">My Dashboard</a> </li>
                                    <li class=""><a href="<?php echo base_url('edit-profile'); ?>" class="cutom-parent">Edit Profile</a> </li>
                                    <li class=""><a href="<?php echo base_url('my-favourite-product'); ?>" class="cutom-parent">My Favourite Products</a> </li>
                                    <li class=""><a href="<?php echo base_url('my-request'); ?>" class="cutom-parent">My Request</a> </li>
                                    <li class=""><a href="<?php echo base_url('order-history'); ?>" class="cutom-parent">Order History</a> </li>
                                    <li class=""><a href="<?php echo base_url('booking-history'); ?>" class="cutom-parent">Booking History</a> </li>
                                    <li class=""><a href="<?php echo base_url('edit-password'); ?>" class="cutom-parent">Edit Password</a> </li>
                                    <li class=""><a href="<?php echo base_url(''); ?>" class="cutom-parent">Logout</a> </li>
                                </ul>
                            </div>
                        </div>
                    </div>