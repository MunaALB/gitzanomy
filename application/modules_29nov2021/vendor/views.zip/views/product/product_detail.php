<style>
    .add-image-gallery button{
        color: black;
        font-size: 12px;
        background: white;
        padding: 5px 10px;
        border-radius: 4px;
        font-weight: 400;
    }
</style>
<div class="content-wrapper">
    <div class="content-header sty-one">
        <h1>Product Detail </h1>
    </div>
    <div class="content eventdeatil">
        <div class="card">
            <div class="">
                <div id="demo">
                    <div class="step-app">
                        <ul class="step-steps">
                            <li class="active"><a href="#step1"><span class="number">1</span>Product Basic Detail</a></li>
                            <li class=""><a href="#step2"><span class="number">2</span>Product Attributes</a></li>
                        </ul>
                        <div class="step-content for-border-remove">
                            <div class="step-tab-panel active" id="step1">
                                <div class="row mb-3">
                                    <div class="col-md-12">
                                        <a href="<?= base_url('vendor/edit-product-detail/' . $product_list['product_id']); ?>" class="composemail pull-right"><i class="fa fa-edit"></i> Edit a product</a>
                                    </div>
                                </div>
                                <div class=" eventdeatil">
                                    <div class="card-header">
                                        <h5 class="text-white m-b-0">Product Information</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="eventrow">
                                            <div class="row mt-3">
                                                <div class="col-lg-3 col-xs-6 b-r">
                                                    <label>Product Category</label>
                                                    <br>
                                                    <p class="text-muted"><?= $product_list['category_name']; ?></p>
                                                </div>
                                                <div class="col-lg-3 col-xs-6 b-r">
                                                    <label>Product SubCategory</label>
                                                    <br>
                                                    <p class="text-muted"><?= $product_list['sub_category_name']; ?></p>
                                                </div>
                                                <div class="col-lg-3 col-xs-6 b-r">
                                                    <label>Product Brand</label>
                                                    <br>
                                                    <p class="text-muted"><?= $product_list['brand_name']; ?></p>
                                                </div>
                                                <div class="col-lg-3 col-xs-6 b-r">
                                                    <label>Product Model</label>
                                                    <br>
                                                    <p class="text-muted"><?= $product_list['model_name']; ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class=" eventdeatil">
                                    <div class="card-header">
                                        <h5 class="text-white m-b-0">Product Basic Detail</h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="eventrow">
                                            <div class="row mt-3">
                                                <div class="col-lg-3 col-xs-6 b-r">
                                                    <label>Product Name</label>
                                                    <br>
                                                    <p class="text-muted"><?= $product_list['name']; ?></p>
                                                </div>
                                                <div class="col-lg-3 col-xs-6 b-r">
                                                    <label>Product Name (Ar)</label>
                                                    <br>
                                                    <p class="text-muted"><?= $product_list['name_ar']; ?></p>
                                                </div>
                                                <div class="col-lg-3 col-xs-6 b-r">
                                                    <label>Discount</label>
                                                    <br>
                                                    <p class="text-muted"><?= $product_list['discount'] ? $product_list['discount'] . '%' : 0; ?></p>
                                                </div>
                                                <div class="col-lg-3 col-xs-6 b-r">
                                                    <label>Expected Delivery</label>
                                                    <br>
                                                    <p class="text-muted"><?= $product_list['expected_delivery']?$product_list['expected_delivery'].' days':''; ?></p>
                                                </div>
                                            </div>
                                            <div class="row mt-3">
                                                <div class="col-lg-12 col-xs-12 b-r">
                                                    <label>Product Description : </label>
                                                    <br>
                                                    <p class="text-muted"><?= $product_list['description']; ?></p>
                                                </div>
                                                <div class="col-lg-12 col-xs-12 b-r">
                                                    <label>Product Description (Ar) : </label>
                                                    <br>
                                                    <p class="text-muted"><?= $product_list['description_ar']; ?></p>
                                                </div>

                                                <div class="col-lg-12 col-xs-12 b-r">
                                                    <label>Terms & Condition : </label>
                                                    <br>
                                                    <p class="text-muted"><?= $product_list['terms']; ?></p>
                                                </div>
                                                <div class="col-lg-12 col-xs-12 b-r">
                                                    <label>Terms & Condition (Ar) : </label>
                                                    <br>
                                                    <p class="text-muted"><?= $product_list['terms_ar']; ?></p>
                                                </div>
                                                <div class="col-lg-4 col-xs-6 b-r">
                                                    <label>Is Returnable</label>
                                                    <br>
                                                    <p class="text-muted"><?php if($product_list['is_returnable']==1){ echo "Yes"; }else{ echo "No"; }?></p>
                                                </div>
                                                <div class="col-lg-4 col-xs-6 b-r">
                                                    <label>Duration </label>
                                                    <br>
                                                    <p class="text-muted"><?php if($product_list['is_returnable']==1){ echo $product_list['duration']." Days"; }else{ echo "N/A"; }?></p>
                                                </div>
                                                <div class="col-lg-12 col-xs-12 b-r">
                                                    <label>Return Policy : </label>
                                                    <br>
                                                    <p class="text-muted"><?php if($product_list['is_returnable']==1){ echo $product_list['return_policy']; }else{ echo "N/A"; }?></p>
                                                </div>
                                                <div class="col-lg-12 col-xs-12 b-r">
                                                    <label>Return Policy (Ar) : </label>
                                                    <br>
                                                    <p class="text-muted"><?php if($product_list['is_returnable']==1){ echo $product_list['return_policy_ar']; }else{ echo "N/A"; }?></p>
                                                </div>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <?php if ($product_list['product_specification']): ?>
                                    <div class="eventdeatil">
                                        <div class="card-header">
                                            <h5 class="text-white m-b-0">Product Specification</h5>
                                        </div>
                                        <div class="card-body">
                                            <div class="eventrow">
                                                <div class="row mt-3">
                                                    <?php foreach ($product_list['product_specification'] as $list): ?>
                                                        <div class="col-lg-3 col-xs-6 b-r">
                                                            <label><?= $list['attribute_name']; ?></label>
                                                            <br>
                                                            <p class="text-muted"><?= $list['attribute_value']; ?></p>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <?php if ($product_list['product_featuers']): ?>
                                    <div class="eventdeatil">
                                        <div class="card-header">
                                            <h5 class="text-white m-b-0">Product Features</h5>
                                        </div>
                                        <div class="card-body">
                                            <div class="eventrow">
                                                <div class="row mt-3">
                                                    <?php foreach ($product_list['product_featuers'] as $list): ?>
                                                        <div class="col-lg-3 col-xs-6 b-r">
                                                            <label><?= $list['name']; ?></label>
                                                            <br>
                                                            <p class="text-muted"><?= $list['value']; ?></p>
                                                        </div>
                                                    <?php endforeach; ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="step-tab-panel for-border-remove booking-detail" id="step2">
                                <?php if (isset($product_list['add_more_attribute']) and $product_list['add_more_attribute']): ?>
                                    <div class="row mb-3">
                                        <div class="col-md-12">
                                            <a href="<?= base_url('vendor/add-more-attribute/' . $product_list['product_id']); ?>" class="composemail pull-right"><i class="fa fa-edit"></i>Add Attributes</a>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <?php
                                if ($product_list['product_attribute_group']):
                                    foreach ($product_list['product_attribute_group'] as $key => $list):
                                        ?>
                                        <div class=" eventdeatil">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h5 class="text-white m-b-0">Item-<?= $key + 1; ?> <span class="add-image-gallery">
                                                            <!--<a href="<?= base_url() ?>vendor/edit-attribute/<?= $product_list['product_id']; ?>/<?= $list['item_id']; ?>">Edit Attributes</a>-->
                                                        </span></h5>
                                                </div>
                                                <div class="card-body">
                                                    <div class="eventrow">
                                                        <div class="row mt-3">

                                                            <div class="col-lg-4 col-xs-6 b-r">
                                                                <label>Item-No</label>
                                                                <br>
                                                                <p class="text-muted"><?= $list['item_no']; ?></p>
                                                            </div>
                                                            <div class="col-lg-4 col-xs-6 b-r">
                                                                <label>Price</label>
                                                                <br>
                                                                <!-- <p class="text-muted"><?= $list['price']; ?> LYD</p> -->
                                                                <p class="text-muted" ><?= number_format(($list['price'] - (($list['price'] * $product_list['discount']) / 100)), 2); ?> LYD</p>
                                                                <?php if ($product_list['discount'] > 0): ?>
                                                                    <p class="text-muted" style="text-decoration: line-through;"><?= number_format($list['price'], 2); ?> LYD</p>                                    
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="col-lg-4 col-xs-6 b-r">
                                                                <label>Quantity</label>
                                                                <br>
                                                                <p class="text-muted"><?= $list['quantity']; ?></p>
                                                            </div>
                                                            <div class="col-lg-4 col-xs-6 b-r">
                                                                <label>Product Discount</label>
                                                                <br>
                                                                <p class="text-muted"><?= $list['discount']; ?>%</p>
                                                            </div>
                                                            <?php if ($list['attribute_data']): foreach ($list['attribute_data'] as $attr): ?>
                                                                    <div class="col-lg-4 col-xs-6 b-r">
                                                                        <label><?= $attr['attribute_name']; ?></label>
                                                                        <br>
                                                                        <p class="text-muted"><?= $attr['attribute_value']; ?></p>
                                                                    </div>
                                                                    <?php
                                                                endforeach;
                                                            endif;
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="card-body">
                                                    <div class="eventrow">
                                                        <div class="row">
                                                            <?php if ($list['imagesArr']): foreach ($list['imagesArr'] as $imgArr): ?>
                                                                    <div class="col-lg-3 col-xs-6 b-r">
                                                                        <a href="#"><img src="<?= $imgArr['image']; ?>" alt="user" class="img-responsive "></a>
                                                                    </div>
                                                                    <?php
                                                                endforeach;
                                                            endif;
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    endforeach;
                                endif;
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
