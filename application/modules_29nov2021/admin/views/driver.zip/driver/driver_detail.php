<style>
    .errorPrint{
        font-size: 12px;
        color: #af2000 !important;
        padding: 5px 5px;
        display: none;
    }
</style>
<div class="content-wrapper">
    <div class="content-header sty-one">
        <h1>Driver Detail</h1>
    </div>
    <div class="content">
        <div class="row">
            <div class="col-lg-4"> 
            <div class="card m-b-3 card-bg-color">
                <div class="card-body">  
                    <img class="profile-user-img img-responsive img-circle" src="<?=$driver_detail['image'];?>" alt="User Avatar">  
                </div>
            </div>
          <div class="card m-b-3">
            <div class="card-body">
              <div class="box-body"> <strong><i class="fa fa-user margin-r-5"></i> Driver Full Name</strong>
                <p class="text-muted"><?=$driver_detail['name'];?></p>
                <hr>
                <!-- <strong><i class="fa fa-car margin-r-5"></i> Bussines Type</strong>
                <p class="text-muted">Driving</p>
                <hr> -->
                <strong><i class="fa fa-envelope margin-r-5"></i> Email address </strong>
                <p class="text-muted"><?=$driver_detail['email'];?></p>
                <hr>
                <strong><i class="fa fa-mobile margin-r-5"></i> Mobile Number</strong>
                <p>+<?=$driver_detail['country_code'];?> <?=$driver_detail['mobile'];?></p> 
                <div class="text-right">
                <?php if($driver_detail['status']==1): ?>
                    <a href="#exampleModal" data-direction="finish" data-toggle="modal" class="composemail">Click To Block</a> 
                <?php else: ?>
                    <a style="cursor:pointer;" onclick="checkStatus_user(this,'<?= $driver_detail['driver_id']; ?>','1');" class="composemail">Click To Verify</a> 
                <?php endif; ?>
                </div>
              </div>
              <!-- /.box-body --> 
            </div>
          </div>
        </div> 

        <div class="col-md-8">
        <div class="card">

            <div class="">

                <div id="demo">

                    <div class="step-app">

                        <ul class="step-steps">

                            <li class="active"><a href="#step1"><span class="number">1</span>Pending Order</a></li>
                            <li><a href="#step2"><span class="number">2</span>Completed Order</a></li>
                            <li><a href="#step3"><span class="number">3</span>Canceled Order</a></li>

                        </ul>

                        <div class="step-content for-border-remove"> 

                            <div class="step-tab-panel active" id="step1">

                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="example1" class="table table-bordered">
                                           <thead>
                                                <tr>
                                                    <th>Order ID</th>
                                                    <th>Vendor Name</th>
                                                    <th>User Name</th>
                                                    <th>Quantity</th>
                                                    <th>Price</th>
                                                </tr>
                                            </thead>   
                                            <tbody>
                                                
                                            </tbody>
                                        </table>
                                    </div>

                                </div>

                            </div> 
                            <div class="step-tab-panel for-border-remove booking-detail" id="step2">

                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="example2" class="table table-bordered">
                                           <thead>
                                                <tr>
                                                    <th>Order ID</th>
                                                    <th>Vendor Name</th>
                                                    <th>User Name</th>
                                                    <th>Quantity</th>
                                                    <th>Price</th>
                                                </tr>
                                            </thead> 
                                            <tbody>
                                                
                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                            </div>
                            <div class="step-tab-panel for-border-remove booking-detail" id="step3">

                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table id="example3" class="table table-bordered">
                                           <thead>
                                                <tr>
                                                    <th>Order ID</th>
                                                    <th>Vendor Name</th>
                                                    <th>User Name</th>
                                                    <th>Quantity</th>
                                                    <th>Price</th>
                                                </tr>
                                            </thead> 
                                            <tbody>
                                                
                                            </tbody>
                                        </table>
                                    </div>

                                </div>
                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>
    </div>
    </div>
    </div>
    <div class="modal fade modal-design" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Block ?</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group mb-4"> 
                            <textarea id="reason" class="form-control"  data-title="Reason" placeholder="Please Enter Your Reason to Block"></textarea>
                            <p class="errorPrint" id="reasonError"></p>
                        </div>
                        <a style="cursor:pointer;" onclick="checkStatus_user(this,'<?= $driver_detail['driver_id']; ?>','2');" class="composemail  pull-right">Submit</a>
                    </form>
                </div>
            </div>
        </div>
    </div>


<script type="text/javascript">
function showErrorMessage(id,msg){
        $("#"+id).empty();
        $("#"+id).append(msg);
        $("#"+id).css('display','block');
    }
    function checkStatus_user(obj, id,status) {
        var reason='';
        var idValidate = false;
        if(status==2){
            reason=$('#reason').val();
            if(reason){

            }else{
                idValidate = true;
            }
        }
        if (idValidate) {
            showErrorMessage('reasonError','*Required Field');
            return false;
        } else {
            if(confirm("Are You sure want to change the status!")){
                if (id) {
                    $.ajax({
                        url: "<?= base_url(); ?>admin/Admin/ajax",
                        type: 'post',
                        data: 'method=ChangeStatusSetting&id=' + id + '&action=' + status+'&type=3'+'&reason='+reason,
                        success: function (data) {
                            var dt = $.trim(data);
                            //alert(dt);
                            var jsonData = $.parseJSON(dt);
                            if (jsonData['error_code'] == "100") {
                                location.reload();
                            } else {
                                alert(jsonData['message']);
                            }
                        }
                    });
                } else {
                    alert("Something Wrong");
                }
            }
        }
    }
</script>