<div class="main-container container">
    <div class="mycart-part">

        <div class="row">

            <div id="content" class="col-sm-12">

                <div class="about-us">

                    <div class="row">

                        <div class="col-lg-12 col-md-12 messege-failure">
                            <i class="fa fa-times-circle-o"></i>

                            <h2 class="about-title">Failure</h2>
                            <p> Some error found.<a href="<?=base_url();?>">Home</a> </p>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>