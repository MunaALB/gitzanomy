<div class="main-container container">
    <div class="mycart-part">

        <div class="row">

            <div id="content" class="col-sm-12">

                <div class="about-us">

                    <div class="row">

                        <div class="col-lg-12 col-md-12 messege-nodata">
                            <i class="fa fa-shopping-bag"></i>

                            <h2 class="about-title">No Data Found</h2>
                            <p> <a href="<?=base_url('');?>">Go To Home</a> </p>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>