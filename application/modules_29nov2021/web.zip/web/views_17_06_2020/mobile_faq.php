<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url(); ?>assets/web/images/logo/favicon.png">
    <title>Zanomy : Libya's Online Shopping Site for Women &amp; Men - Latest Online Shopping Trends</title>
    <meta name="description" content="Online Fashion Shopping Store For Women at Best Price in Libya. Buy Women Clothing, Shoes, Handbags, Jewellery, Sunglasses, Accessories at Zanomy." />
    <meta name="keywords" content="Zanomy, Online Shopping, Online Shopping  in Libya, Online Shopping Site for Women &amp; Men, Latest Online Shopping Trends" />
    <meta name="author" content="Zanomy" />
    <link href="https://www.zanomy.com/" rel="canonical" />
    <meta name="Classification" content="Zanomy" />
    <meta name="abstract" content="https://www.zanomy.com/" />
    <meta name="audience" content="All" />
    <meta name="robots" content="index,follow" />
    <meta property="og:locale" content="en_US" />
    <meta property="og:title" content="Zanomy : Libya's  Online Shopping Site for Women &amp; Men - Latest Online Shopping Trends" />
    <meta property="og:description" content="Online Fashion Shopping Store For Women at Best Price in Libya. Buy Women Clothing, Shoes, Handbags, Jewellery, Sunglasses, Accessories at Zanomy." />
    <meta property="og:url" content="https://www.zanomy.com/" />
    <meta property="og:image" content="<?php echo base_url(); ?>assets/web/images/logo/og.png" />
    <meta property="og:site_name" content="Zanomy" />
    <meta name="googlebot" content="index,follow" />
    <meta name="distribution" content="Global" />
    <meta name="Language" content="en-us" />
    <meta name="doc-type" content="Public" />
    <meta name="site_name" content="Zanomy" />
    <meta name="url" content="https://www.zanomy.com/" />
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/css/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/css/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/js/datetimepicker/bootstrap-datetimepicker.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/js/owl-carousel/owl.carousel.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/css/themecss/lib.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/js/jquery-ui/jquery-ui.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/js/minicolors/miniColors.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/css/themecss/so_searchpro.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/css/themecss/so_megamenu.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/css/themecss/so-categories.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/css/themecss/so-listing-tabs.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/css/themecss/so-newletter-popup.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/css/header/header3.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/css/footer/footer3.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/css/home3.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/css/theme.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/css/responsive.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/web/fonts/stylesheet.css">
    <script src="<?=base_url()?>assets/web/js/jquery-2.2.4.min.js"></script>
    <style type="text/css">
        .pt-50{
            padding-top: 50px;
        }
    </style>
    <body>
<div class="main-container container">
    <div class="mycart-part pt-50">
        <div class="row">
<div id="content" class="col-sm-12">
    <h3>Got Questions? We’ve Got Answers!</h3>
    <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.</p>
    <p>
        <br>
    </p>
    <div class="row">
        <div class="col-sm-12">
            <ul class="yt-accordion">
                <li class="accordion-group">
                    <h3 class="accordion-heading active"><i class="fa fa-plus-square"></i><span>Lorem ipsum dolor sit amet, consectetuer adipiscing elit</span></h3>
                    <div class="accordion-inner">
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.Lorem ipsum dolor  </p>
                        <p>sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.</p>
                    </div>
                </li>
                <li class="accordion-group">
                    <h3 class="accordion-heading"><i class="fa fa-plus-square"></i><span>Donec eros tellus scelerisque nec rhoncus eget laoreet sit amet</span></h3>
                    <div class="accordion-inner" style="display: none;">
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.Lorem ipsum dolor  </p>
                        <p>sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.</p>
                    </div>
                </li>
                <li class="accordion-group">
                    <h3 class="accordion-heading"><i class="fa fa-plus-square"></i><span>Curabitur molestie euismod erat. Proin eros odio?</span></h3>
                    <div class="accordion-inner" style="display: none;">
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.Lorem ipsum dolor  </p>
                        <p>sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.</p>
                    </div>
                </li>
                <li class="accordion-group">
                    <h3 class="accordion-heading"><i class="fa fa-plus-square"></i><span>In scelerisque sem at dolor. Maecenas mattis</span></h3>
                    <div class="accordion-inner" style="display: none;">
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.Lorem ipsum dolor  </p>
                        <p>sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.</p>
                    </div>
                </li>
                <li class="accordion-group">
                    <h3 class="accordion-heading"><i class="fa fa-plus-square"></i><span>Nunc feugiat mi a tellus consequat imperdiet</span></h3>
                    <div class="accordion-inner" style="display: none;">
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.Lorem ipsum dolor  </p>
                        <p>sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.</p>
                    </div>
                </li>
                <li class="accordion-group">
                    <h3 class="accordion-heading"><i class="fa fa-plus-square"></i><span>Vestibulum ante ipsum primis in faucibus orci luctus </span></h3>
                    <div class="accordion-inner" style="display: none;">
                        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.Lorem ipsum dolor  </p>
                        <p>sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.</p>
                    </div>
                </li>
                <li class="accordion-group">
                    <h3 class="accordion-heading"><i class="fa fa-plus-square"></i><span>SmartAddons membership fee is one-time fee, or I have to pay extra?</span></h3>
                    <div class="accordion-inner" style="display: none;">
                         <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu.Lorem ipsum dolor  </p>
                        <p>sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.</p>
                    </div>
                </li>
            </ul>
        </div>
    </div>

</div>
        </div>
    </div>
</div>

<script src="<?=base_url()?>assets/web/js/jquery-2.2.4.min.js"></script>
<script src="<?=base_url()?>assets/web/js/bootstrap.min.js"></script>
<script src="<?=base_url()?>assets/web/js/owl-carousel/owl.carousel.js"></script>
<script src="<?=base_url()?>assets/web/js/themejs/libs.js"></script>
<script src="<?=base_url()?>assets/web/js/unveil/jquery.unveil.js"></script>
<script src="<?=base_url()?>assets/web/js/countdown/jquery.countdown.min.js"></script>
<script src="<?=base_url()?>assets/web/js/dcjqaccordion/jquery.dcjqaccordion.2.8.min.js"></script>
<script src="<?=base_url()?>assets/web/js/datetimepicker/moment.js"></script>
<script src="<?=base_url()?>assets/web/js/datetimepicker/bootstrap-datetimepicker.min.js"></script>
<script src="<?=base_url()?>assets/web/js/jquery-ui/jquery-ui.min.js"></script>
<script src="<?=base_url()?>assets/web/js/modernizr/modernizr-2.6.2.min.js"></script>
<script src="<?=base_url()?>assets/web/js/minicolors/jquery.miniColors.min.js"></script>
<script src="<?=base_url()?>assets/web/js/themejs/application.js"></script>
<script src="<?=base_url()?>assets/web/js/themejs/homepage.js"></script>
<script src="<?=base_url()?>assets/web/js/themejs/toppanel.js"></script>
<script src="<?=base_url()?>assets/web/js/themejs/so_megamenu.js"></script>
<script src="<?=base_url()?>assets/web/js/themejs/addtocart.js"></script>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> -->
<script>
    function userLogout(){
        if(confirm("Are you sure want to logout!")){
            window.location.href="<?=base_url('logout');?>";
        }
    }
</script>
<script>
    $(document).ready(function () {
        $(document)
        .ajaxStart(function () {
            $('.ajax-loader').css("visibility", "visible");
        })
        .ajaxStop(function () {
            $('.ajax-loader').css("visibility", "hidden");
        });
    });
    
    ///////////////////////////LOADER//////////////
    window.addEventListener( 'load', function () {

        var shwload = document.getElementById( "page_loader" );

        shwload.style.display = "none";

    } )
    ///////////////////////////LOADER//////////////
</script>
<script type="text/javascript">
        $("#show-megamenu").click(function () {
        if($('.megamenu-wrapper').hasClass('so-megamenu-active'))
            $('.megamenu-wrapper').removeClass('so-megamenu-active');
        else
            $('.megamenu-wrapper').addClass('so-megamenu-active');
    }); 
    $('#remove-megamenu').click(function() {
        $('.megamenu-wrapper').removeClass('so-megamenu-active');
        return false;
    }); 
</script>
</body>

</html>
