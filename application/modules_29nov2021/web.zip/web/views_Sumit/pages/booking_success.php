<div class="main-container container">
    <div class="mycart-part">

        <div class="row">

            <div id="content" class="col-sm-12">

                <div class="about-us">

                    <div class="row">

                        <div class="col-lg-12 col-md-12 messege-success">
                            <i class="fa fa-check-circle"></i>

                            <h2 class="about-title">Success</h2>
                            <p>Booking successfully confirmed. <a href="#">View Booking</a></p>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>
