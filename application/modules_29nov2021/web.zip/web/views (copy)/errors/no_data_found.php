<div id="product-product" class="container mx-auto">
    <div class="row">
        <div id="content" class="col-sm-12 productpage">
            <div class="notdatafounderror">
                <img src="<?php echo base_url(); ?>assets/web/images/opps-error.png"  alt="no data found">
                <h5><?=$message?></h5>
            </div>
        </div>
    </div>
</div>